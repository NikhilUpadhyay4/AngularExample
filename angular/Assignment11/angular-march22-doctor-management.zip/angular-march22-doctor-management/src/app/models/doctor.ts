export type User = {
    name:string;
}