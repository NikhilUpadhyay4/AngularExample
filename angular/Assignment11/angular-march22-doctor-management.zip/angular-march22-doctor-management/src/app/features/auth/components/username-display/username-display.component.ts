import { Component, OnInit } from '@angular/core';
import { map ,pipe} from 'rxjs';
import { LoginResponse } from 'src/app/models/user';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-username-display',
  templateUrl: './username-display.component.html',
  styleUrls: ['./username-display.component.css']
})
export class UsernameDisplayComponent implements OnInit {
public username:string  ='';
// public login?:string
  constructor(private auth:AuthService) { }

  ngOnInit(): void {
    this.auth.isLogin$.subscribe((val:LoginResponse |null)=>{
      if (val == null) {
        this.username='default username'
      } else {
        this.username = val.user.username
      }
    })
    
  }

}
