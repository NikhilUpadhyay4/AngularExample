import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Role } from 'src/app/models/role';
import { LoginResponse, User } from 'src/app/models/user';
import { BehaviorSubject } from 'rxjs';
import { stringify } from '@angular/compiler/src/util';
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private _user!: User;
  private _authToken?: string;

  loginUser!: LoginResponse;

  public isLogin$:BehaviorSubject<LoginResponse | null >  = new BehaviorSubject<LoginResponse | null>(this.loginUser);

  constructor(private http: HttpClient) { }

  login(): void {
    this.loginUser={ access_token: this._authToken+"" , user: this._user }
    sessionStorage.setItem('token', stringify(this.loginUser));
    this.isLogin$.next(this.loginUser);

  }



  logout(): void {
    sessionStorage.removeItem('token');
    this.isLogin$.next(null);
  }

  storeDetails(res: LoginResponse) {
    //store in sessionStorage
    this._user = res.user;
    this._authToken = res.access_token;
    this.login();
  }

  // private hasToken(): boolean {
  //   return !!sessionStorage.getItem('token');
  // }

  isUserLoggedIn(): boolean {
    return !!this._authToken;
  }

  getAuthToken() {
    return this._authToken;
  }

  getUserRole(): Role | undefined {
    return this._user?.role;
  }

  getUserDetails() {
    return this._user;
  }

  createUser() {
    return this.http.post<LoginResponse>('/api/auth/login', {
      username: 'john',
      password: 'changeme'
    }).pipe(
      tap((response: LoginResponse) => {
        this.storeDetails(response);
      })
    );
  }
}
